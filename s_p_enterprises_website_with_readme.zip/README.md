# 🌐 S&P ENTERPRISES Website

This is the official website for **S&P ENTERPRISES**, created with **Next.js + Tailwind CSS**.

## 📌 Features
- Company Profile & About Page
- Services (Bill Distribution, Meter Reading, Gas, Aadhaar/PAN/Passport, etc.)
- Contact Page with Form + Details
- Responsive & Mobile-Friendly
- Ready to Deploy on **Vercel** 🚀

---

## ⚡ How to Deploy

### 1. Upload to GitHub
1. Go to [GitHub](https://github.com) → log in.
2. Create a **New Repository** → name it:
   ```
   sandp-enterprises-website
   ```
3. Upload all files from the project folder (unzipped).
4. Commit changes ✅

---

### 2. Deploy with Vercel
1. Go to [Vercel New Project](https://vercel.com/new).
2. Import the repo **sandp-enterprises-website**.
3. Framework: **Next.js** (auto detected).
4. Click **Deploy** 🚀

---

### 3. Live Website
After deployment, your live site will be available at:
```
https://sandp-enterprises.vercel.app
```
(you can also connect a custom domain).

---

## 🔧 Contact Form Setup
The contact form is included but not connected.
To enable:
1. Create free account at [Formspree](https://formspree.io).
2. Get your **form endpoint URL**.
3. Open `components/ContactForm.js` → replace `FORM_ENDPOINT` with your URL.
4. Redeploy on Vercel.

---

## 👤 Company Details
**Owner**: Satish Dhakne  
**Company**: S&P ENTERPRISES  
**Address**: Shop No 5, Krishna Colony, Opp SBI Bank, R T Road, Dahisar East, Mumbai 400068  
**Phone**: 9892255431 / 9702055431  
**Email**: sandpenterprises793@gmail.com  
